import 'package:flutter/material.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'dart:convert';

void main() {
  runApp(VisualNovelEditorApp());
}

class VisualNovelEditorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VN Engine',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        brightness: Brightness.dark,
      ),
      home: ProjectManagerScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// (Rest of the Dart code remains unchanged to keep this short)